package org.example.demo.climb.model.bean.__to_delete;

public class Commentaire {
}
