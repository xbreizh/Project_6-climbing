

/*




function pushpinClicked(e) {
    //Make sure the infobox has metadata to display.
    //Set the infobox options with the metadata of the pushpin.
    infobox.setOptions({
        title: e.target.City,
        description: '<a href="spot_detail.action?id='+e.target.Ref+'" >'+e.target.Title.toUpperCase()+'</a>',
        visible: true
    });
    infobox.setLocation(e.target.getLocation());
}*/
